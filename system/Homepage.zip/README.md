
  # Homepage for Nasugbu Computer Parts

  This is a code bundle for Homepage for Nasugbu Computer Parts. The original project is available at https://www.figma.com/design/Kdj2iS7oSBt4Xbs8KEvczE/Homepage-for-Nasugbu-Computer-Parts.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  