import { Camera, Wrench, HardDrive, Smartphone, Laptop, Monitor, ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Services() {
  const mainServices = [
    {
      icon: Camera,
      title: "CCTV Installation",
      description: "Professional CCTV camera installation and setup for homes and businesses. Complete surveillance solutions with remote monitoring capabilities.",
      image: "https://images.unsplash.com/photo-1566060475410-1159300f046f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWN1cml0eSUyMGNhbWVyYSUyMGNjdHZ8ZW58MXx8fHwxNzY0NTUzMDkxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["HD Camera Setup", "Remote Access", "24/7 Recording", "Motion Detection"]
    },
    {
      icon: Wrench,
      title: "Gadgets Repair",
      description: "Expert repair services for all your electronic devices. Fast, reliable, and affordable solutions to get your gadgets working like new.",
      image: "https://images.unsplash.com/photo-1646756089735-487709743361?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMHJlcGFpciUyMHRlY2huaWNpYW58ZW58MXx8fHwxNzY0NDY4NTk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      features: ["Phone Repair", "Laptop Repair", "Tablet Repair", "Data Recovery"]
    }
  ];

  const additionalServices = [
    {
      icon: HardDrive,
      title: "Computer Parts",
      description: "Quality computer components and peripherals for sale.",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Smartphone,
      title: "Phone Services",
      description: "Screen replacement, battery change, and software fixes.",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: Laptop,
      title: "Laptop Upgrade",
      description: "RAM, SSD, and hardware upgrade services.",
      color: "from-green-500 to-green-600"
    },
    {
      icon: Monitor,
      title: "System Build",
      description: "Custom PC building and assembly services.",
      color: "from-orange-500 to-orange-600"
    }
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#0b4f6c]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#0b4f6c]/5 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block bg-gradient-to-r from-[#0b4f6c] to-[#1a7a9e] text-white px-6 py-3 rounded-full mb-4 shadow-lg">
            <span className="text-sm">Our Services</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4 text-gray-900">What We Offer</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive tech solutions tailored to meet your needs
          </p>
        </div>

        {/* Main Services */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {mainServices.map((service, index) => {
            const Icon = service.icon;
            return (
              <div key={index} className="group bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                <div className="relative h-72 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10"></div>
                  <ImageWithFallback
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute bottom-6 left-6 z-20 flex items-center gap-3">
                    <div className="bg-white p-3 rounded-xl shadow-lg">
                      <Icon className="w-7 h-7 text-[#0b4f6c]" />
                    </div>
                    <h3 className="text-3xl text-white">{service.title}</h3>
                  </div>
                </div>
                <div className="p-8">
                  <p className="text-gray-600 mb-6 text-lg leading-relaxed">{service.description}</p>
                  <div className="grid grid-cols-2 gap-4">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-gray-700 bg-gray-50 px-3 py-2 rounded-lg">
                        <div className="w-2 h-2 bg-gradient-to-r from-[#0b4f6c] to-[#1a7a9e] rounded-full"></div>
                        {feature}
                      </div>
                    ))}
                  </div>
                  <button className="mt-6 text-[#0b4f6c] flex items-center gap-2 group-hover:gap-3 transition-all">
                    Learn More
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Additional Services */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {additionalServices.map((service, index) => {
            const Icon = service.icon;
            return (
              <div key={index} className="group bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100">
                <div className={`bg-gradient-to-br ${service.color} w-14 h-14 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h4 className="text-xl mb-2 text-gray-900">{service.title}</h4>
                <p className="text-gray-600 text-sm leading-relaxed">{service.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}