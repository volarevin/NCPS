import { Mail, Phone, MapPin, Clock, Send } from "lucide-react";
import { useState } from "react";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form submission logic here
    console.log("Form submitted:", formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.id]: e.target.value
    });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      detail: "+63 123 456 7890",
      link: "tel:+631234567890",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Mail,
      title: "Email",
      detail: "info@nasugbucomputer.com",
      link: "mailto:info@nasugbucomputer.com",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: MapPin,
      title: "Location",
      detail: "Brias Street, Barangay 3, Nasugbu, Batangas",
      link: "https://maps.google.com/?q=3JCJ+RJJ,+Brias+Street,+Barangay+3,+Nasugbu,+Batangas",
      color: "from-green-500 to-green-600"
    },
    {
      icon: Clock,
      title: "Business Hours",
      detail: "Mon - Sat: 9AM - 6PM",
      link: "#",
      color: "from-orange-500 to-orange-600"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-[#0b4f6c]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-0 w-96 h-96 bg-[#0b4f6c]/5 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block bg-gradient-to-r from-[#0b4f6c] to-[#1a7a9e] text-white px-6 py-3 rounded-full mb-4 shadow-lg">
            <span className="text-sm">Contact Us</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4 text-gray-900">Get In Touch</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Have a question or need our services? We're here to help!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-7xl mx-auto mb-16">
          {/* Contact Information */}
          <div className="space-y-8">
            <h3 className="text-3xl text-gray-900">Contact Information</h3>
            <div className="space-y-4">
              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                return (
                  <a
                    key={index}
                    href={info.link}
                    target={info.title === "Location" ? "_blank" : undefined}
                    rel={info.title === "Location" ? "noopener noreferrer" : undefined}
                    className="group flex items-start gap-4 p-6 bg-white rounded-2xl hover:shadow-xl transition-all duration-300 border border-gray-100 hover:-translate-y-1"
                  >
                    <div className={`bg-gradient-to-br ${info.color} p-4 rounded-xl shadow-lg group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-gray-900 mb-1">{info.title}</div>
                      <div className="text-gray-600">{info.detail}</div>
                    </div>
                  </a>
                );
              })}
            </div>

            {/* CTA Box */}
            <div className="bg-gradient-to-br from-[#0b4f6c] to-[#1a7a9e] text-white p-8 rounded-3xl shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
              <div className="relative z-10">
                <h4 className="text-2xl mb-4">Ready to get started?</h4>
                <p className="mb-6 text-gray-100 leading-relaxed">
                  Contact us today for a free consultation and quote for your CCTV installation or repair needs.
                </p>
                <a
                  href="tel:+631234567890"
                  className="inline-flex items-center gap-2 bg-white text-[#0b4f6c] px-6 py-3 rounded-xl hover:bg-gray-100 transition-all hover:scale-105 shadow-lg"
                >
                  <Phone className="w-5 h-5" />
                  Call Us Now
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white p-8 md:p-10 rounded-3xl shadow-2xl border border-gray-100">
            <h3 className="text-3xl mb-8 text-gray-900">Send Us a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0b4f6c] focus:border-transparent transition-all bg-gray-50 focus:bg-white"
                  placeholder="Juan Dela Cruz"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0b4f6c] focus:border-transparent transition-all bg-gray-50 focus:bg-white"
                  placeholder="juan@example.com"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-gray-700 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  id="phone"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0b4f6c] focus:border-transparent transition-all bg-gray-50 focus:bg-white"
                  placeholder="+63 123 456 7890"
                />
              </div>
              <div>
                <label htmlFor="service" className="block text-gray-700 mb-2">
                  Service Needed *
                </label>
                <select
                  id="service"
                  required
                  value={formData.service}
                  onChange={handleChange}
                  className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0b4f6c] focus:border-transparent transition-all bg-gray-50 focus:bg-white"
                >
                  <option value="">Select a service</option>
                  <option value="cctv">CCTV Installation</option>
                  <option value="repair">Gadget Repair</option>
                  <option value="parts">Computer Parts</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label htmlFor="message" className="block text-gray-700 mb-2">
                  Message *
                </label>
                <textarea
                  id="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0b4f6c] focus:border-transparent resize-none transition-all bg-gray-50 focus:bg-white"
                  placeholder="Tell us about your needs..."
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-[#0b4f6c] to-[#1a7a9e] text-white py-4 rounded-xl hover:shadow-xl transition-all hover:scale-[1.02] flex items-center justify-center gap-2 group"
              >
                Send Message
                <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>

        {/* Google Maps Embed */}
        <div className="max-w-7xl mx-auto">
          <div className="bg-white p-4 rounded-3xl shadow-2xl border border-gray-100">
            <h3 className="text-2xl mb-4 text-gray-900 px-4">Visit Our Store</h3>
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d964.2374147774494!2d120.63117856951983!3d14.071980099286647!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33bd9c7f8f8f8f8f%3A0x0!2zMTTCsDA0JzE5LjEiTiAxMjDCsDM3JzUyLjQiRQ!5e0!3m2!1sen!2sph!4v1234567890"
                width="100%"
                height="450"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Nasugbu Computer Parts and Services Location"
                className="w-full"
              ></iframe>
            </div>
            <div className="mt-4 px-4 pb-2">
              <p className="text-gray-600 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#0b4f6c]" />
                <span>3JCJ+RJJ, Brias Street, Barangay 3, Nasugbu, Batangas</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}