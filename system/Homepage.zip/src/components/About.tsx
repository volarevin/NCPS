import { Award, Users, Clock, ThumbsUp } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function About() {
  const features = [
    {
      icon: Award,
      title: "Expert Technicians",
      description: "Certified professionals with years of experience"
    },
    {
      icon: Users,
      title: "Customer Focused",
      description: "Your satisfaction is our top priority"
    },
    {
      icon: Clock,
      title: "Fast Service",
      description: "Quick turnaround time on all repairs"
    },
    {
      icon: ThumbsUp,
      title: "Quality Assured",
      description: "All work comes with warranty guarantee"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <div className="inline-block bg-[#0b4f6c]/10 text-[#0b4f6c] px-4 py-2 rounded-full mb-4">
              About Us
            </div>
            <h2 className="text-4xl md:text-5xl mb-6 text-gray-900">
              Your Trusted Technology Partner
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Nasugbu Computer Parts and Services has been serving the community with top-quality tech solutions. We specialize in CCTV installations and gadget repairs, providing reliable and professional services.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              Our team of experienced technicians is dedicated to delivering exceptional service, whether you need a complete security system installation or a quick phone repair. We use only quality parts and the latest techniques to ensure your satisfaction.
            </p>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-6">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="flex gap-3">
                    <div className="bg-[#0b4f6c]/10 p-2 rounded-lg h-fit">
                      <Icon className="w-5 h-5 text-[#0b4f6c]" />
                    </div>
                    <div>
                      <h4 className="text-gray-900 mb-1">{feature.title}</h4>
                      <p className="text-sm text-gray-600">{feature.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Content - Image */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1563770660834-82b48f27ec9d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljcyUyMHdvcmtzaG9wJTIwdG9vbHN8ZW58MXx8fHwxNzY0NTUzMDkyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Computer workshop"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Decorative Element */}
            <div className="absolute -bottom-6 -right-6 bg-[#0b4f6c] w-32 h-32 rounded-2xl -z-10"></div>
            <div className="absolute -top-6 -left-6 bg-[#0b4f6c]/10 w-32 h-32 rounded-2xl -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
