import { Star, Quote } from "lucide-react";

export function Testimonials() {
  const testimonials = [
    {
      name: "Maria Santos",
      role: "Homeowner",
      content: "Excellent CCTV installation service! The team was professional, and the system works perfectly. I feel much safer now.",
      rating: 5,
      image: "MS"
    },
    {
      name: "Roberto Cruz",
      role: "Business Owner",
      content: "Fast and reliable gadget repair. They fixed my laptop in just 2 days. Highly recommended for computer services!",
      rating: 5,
      image: "RC"
    },
    {
      name: "Ana Reyes",
      role: "Store Manager",
      content: "Professional service and fair prices. They helped us set up a complete surveillance system for our store. Great work!",
      rating: 5,
      image: "AR"
    }
  ];

  return (
    <section className="py-20 bg-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-[#0b4f6c] rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-[#0b4f6c] rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block bg-gradient-to-r from-[#0b4f6c] to-[#1a7a9e] text-white px-6 py-3 rounded-full mb-4 shadow-lg">
            <span className="text-sm">Testimonials</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4 text-gray-900">What Our Clients Say</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied customers
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-gray-50 to-white p-8 rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100 relative"
            >
              {/* Quote Icon */}
              <div className="absolute top-6 right-6 text-[#0b4f6c]/10">
                <Quote className="w-16 h-16" fill="currentColor" />
              </div>

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              {/* Content */}
              <p className="text-gray-700 mb-6 leading-relaxed relative z-10">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#0b4f6c] to-[#1a7a9e] rounded-full flex items-center justify-center text-white shadow-lg">
                  {testimonial.image}
                </div>
                <div>
                  <div className="text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="text-4xl mb-2 text-[#0b4f6c]">500+</div>
            <div className="text-gray-600">Happy Clients</div>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-2 text-[#0b4f6c]">5.0</div>
            <div className="text-gray-600">Average Rating</div>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-2 text-[#0b4f6c]">1000+</div>
            <div className="text-gray-600">Repairs Done</div>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-2 text-[#0b4f6c]">5+</div>
            <div className="text-gray-600">Years Experience</div>
          </div>
        </div>
      </div>
    </section>
  );
}
